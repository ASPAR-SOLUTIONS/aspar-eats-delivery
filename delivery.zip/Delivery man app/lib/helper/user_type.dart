enum UserType {
  vendor,
  user,
  customer,
  delivery_man
}
