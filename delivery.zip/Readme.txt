If you need only the changed files for mobile apps in V1.6 check the change files from V1.5 to V1.6 folder
otherwise please use "Delivery man app" folder.

Documentation - https://docs.6amtech.com/